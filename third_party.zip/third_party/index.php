<?php

define('SYSTEM_PATH', '');
require_once SYSTEM_PATH.'vendor/autoload.php';

